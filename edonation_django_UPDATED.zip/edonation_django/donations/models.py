from django.db import models


class Donation(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    mobile = models.CharField(max_length=15)
    item = models.CharField(max_length=100)
    category = models.CharField(max_length=50)
    item_condition = models.CharField(max_length=50)
    location = models.CharField(max_length=200)
    description = models.TextField()
    status = models.CharField(max_length=20, default="Pending")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.item} - {self.name}"
