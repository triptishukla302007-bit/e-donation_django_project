from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login, logout
from .models import Donation


def home(request):
    return render(request, 'index.html')


def donate(request):
    if request.method == 'POST':
        Donation.objects.create(
            name=request.POST.get('name'),
            email=request.POST.get('email'),
            mobile=request.POST.get('mobile'),
            item=request.POST.get('item'),
            category=request.POST.get('category'),
            item_condition=request.POST.get('item_condition'),
            location=request.POST.get('location'),
            description=request.POST.get('description'),
        )
        messages.success(request, 'Donation submitted successfully!')
        return redirect('donate')

    return render(request, 'donate.html')


def register(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        password = request.POST.get('password')

        if User.objects.filter(username=email).exists():
            messages.error(request, 'An account with this email already exists.')
            return redirect('register')

        user = User.objects.create_user(
            username=email,
            email=email,
            password=password,
            first_name=name
        )

        auth_login(request, user)
        messages.success(request, 'Registration successful!')
        return redirect('home')

    return render(request, 'register.html')


def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = authenticate(request, username=email, password=password)

        if user is not None:
            auth_login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid email or password.')

    return render(request, 'login.html')


def logout_user(request):
    logout(request)
    return redirect('home')


def admin_dashboard(request):
    donations = Donation.objects.all().order_by('-created_at')

    pending_count = Donation.objects.filter(status='Pending').count()
    approved_count = Donation.objects.filter(status='Approved').count()

    return render(request, 'admin.html', {
        'donations': donations,
        'pending_count': pending_count,
        'approved_count': approved_count,
    })


def update_status(request, donation_id):
    donation = get_object_or_404(Donation, id=donation_id)

    if request.method == 'POST':
        donation.status = 'Approved'
        donation.save()

    return redirect('admin_dashboard')
