from django.contrib import admin
from django.urls import path
from donations import views

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', views.home, name='home'),
    path('donate/', views.donate, name='donate'),
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout_user, name='logout'),

    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('update_status/<int:donation_id>/', views.update_status, name='update_status'),
]
